const sinon = require('sinon');
const fs = require('fs');

function mockFs(readData = '[]') {
  sinon.stub(fs.promises, 'readFile').resolves(readData);
  sinon.stub(fs.promises, 'writeFile').resolves();
}

function restoreFs() {
  sinon.restore();
}

module.exports = { mockFs, restoreFs };
