const request = require('supertest');
const app = require('../server');
const { expect } = require('chai');
const reset = require('./helpers/reset');

describe('Notes API (Integration)', () => {

  beforeEach(async () => {
    await reset();
  });

  it('should create note', async () => {
    const res = await request(app)
      .post('/notes')
      .send({ title: 'Test', content: 'Hello' });

    expect(res.status).to.equal(201);
  });

  it('should update note', async () => {
    const create = await request(app)
      .post('/notes')
      .send({ title: 'Old', content: 'Old content' });

    const id = create.body.id;

    const res = await request(app)
      .put(`/notes/${id}`)
      .send({ content: 'Updated' });

    expect(res.status).to.equal(200);
  });

  it('should delete note', async () => {
    const create = await request(app)
      .post('/notes')
      .send({ title: 'Delete', content: 'Me' });

    const id = create.body.id;

    const res = await request(app)
      .delete(`/notes/${id}`);

    expect(res.status).to.equal(200);
  });

});
