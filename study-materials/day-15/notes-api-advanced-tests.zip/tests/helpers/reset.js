const fs = require('fs').promises;

module.exports = async function reset() {
  await fs.writeFile('./data/notes.json', JSON.stringify([]));
};
