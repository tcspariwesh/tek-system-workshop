const { getNotes, saveNotes } = require('../services/notesService');
const { noteSchema } = require('../validators/noteValidator');

exports.getAllNotes = async (req, res) => {
  const notes = await getNotes();
  res.json(notes);
};

exports.createNote = async (req, res) => {
  const validation = noteSchema.safeParse(req.body);
  if (!validation.success) {
    return res.status(400).json({ error: validation.error.errors });
  }
  const notes = await getNotes();
  const newNote = { id: Date.now(), ...validation.data };
  notes.push(newNote);
  await saveNotes(notes);
  res.status(201).json(newNote);
};

exports.getNoteById = async (req, res) => {
  const notes = await getNotes();
  const note = notes.find(n => n.id == req.params.id);
  if (!note) return res.status(404).json({ error: 'Not found' });
  res.json(note);
};

exports.updateNote = async (req, res) => {
  const notes = await getNotes();
  const updated = notes.map(n =>
    n.id == req.params.id ? { ...n, ...req.body } : n
  );
  await saveNotes(updated);
  res.json({ message: 'Updated' });
};

exports.deleteNote = async (req, res) => {
  const notes = await getNotes();
  const filtered = notes.filter(n => n.id != req.params.id);
  await saveNotes(filtered);
  res.json({ message: 'Deleted' });
};
