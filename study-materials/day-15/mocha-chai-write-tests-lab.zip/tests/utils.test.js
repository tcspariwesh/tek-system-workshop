// 🧪 Write your tests here using Mocha & Chai

const { expect } = require('chai');
const { add, subtract, isEven, fetchData } = require('../src/utils');

describe('Utils Tests', () => {

  // 👉 Write your own test cases here

});
