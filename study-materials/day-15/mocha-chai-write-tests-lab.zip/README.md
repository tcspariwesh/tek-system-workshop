# 🧪 Write Tests From Scratch Lab

## 🎯 Objective
Write complete test cases using Mocha & Chai.

## 📦 Setup
npm install

## ▶ Run
npm test

## 🧠 Your Tasks

Write tests for:

1. add(a, b)
2. subtract(a, b)
3. isEven(n)
4. fetchData() (async)

## ⚠️ Rules
- No hints provided
- Cover edge cases
- Use proper assertions
- Handle async correctly

## 🚀 Goal
Write clean, complete test suite like a real developer
