// Functions to test

function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function isEven(n) {
  return n % 2 === 0;
}

async function fetchData() {
  return new Promise(resolve => {
    setTimeout(() => resolve("data"), 100);
  });
}

module.exports = { add, subtract, isEven, fetchData };
